<!DOCTYPE html>
<html>
<head>
	<title>sistema de cadastro</title>
</head>
<body>

	<a href="form_pessoa.php">Cadastro de pessoas</a>

	<br><br>


	<a href="index.php">Realizar Login</a>

</body>
</html>