<?php
require './init.php';
 
// pega o ID da URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
 
// valida o ID
if (empty($id))
{
    echo "ID para alteração não definido";
    exit;
}
 
// busca os dados du usuário a ser editado
$PDO = db_connect();
$sql = "SELECT modelo, cor, ano, preco FROM carro WHERE id = :id";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
 
$stmt->execute();
 
$carro = $stmt->fetch(PDO::FETCH_ASSOC);
 
// se o método fetch() não retornar um array, significa que o ID não corresponde a um usuário válido
if (!is_array($carro))
{
    echo "Nenhum usuário encontrado";
    exit;
}
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
 
        <title>Edição de Usuário - ULTIMATE PHP</title>
    </head>
 
    <body>
 
        <h1>Sistema de Cadastro - ULTIMATE PHP</h1>
 
        <h2>Edição de carros</h2>
         
        <form action="add_formulario_edite.php" method="post">
            <label for="modelo">Modelo: </label>
            <br>
            <input type="text" name="modelo" id="modelo" value="<?php echo $carro['modelo'] ?>">
 
            <br><br>
 
            <label for="cor">Cor: </label>
            <br>
            <input type="text" name="cor" id="cor" value="<?php echo $carro['cor'] ?>">
 
            <br><br>
             <label for="ano">Ano: </label>
             <br>
            <input type="date" name="ano" id="ano" value="<?php echo $carro['ano'] ?>">
 
            <br><br>
             <label for="preco">Preço: </label>
             <br>
            <input type="number" name="preco" id="preco" value="<?php echo $carro['preco'] ?>">
 
            <br><br>
             
           
            <input type="hidden" name="id" value="<?php echo $id ?>">
 
            <input type="submit" value="Alterar">
        </form>
 
    </body>
</html>