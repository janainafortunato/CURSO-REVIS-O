<?php
 
require_once './init.php';
 
// resgata os valores do formulário
$modelo = isset($_POST['modelo']) ? $_POST['modelo'] : null;
$cor = isset($_POST['cor']) ? $_POST['cor'] : null;
$ano = isset($_POST['ano']) ? $_POST['ano'] : null;
$preco = isset($_POST['preco']) ? $_POST['preco'] : null;
$id = isset($_POST['id']) ? $_POST['id'] : null;
 
// validação (bem simples, mais uma vez)
if (empty($modelo) || empty($cor) || empty($ano) || empty($preco))
{
    echo "Volte e preencha todos os campos";
    exit;
}
 

// atualiza o banco
$PDO = db_connect();
$sql = "UPDATE carro SET modelo = :modelo, cor = :cor, ano = :ano, preco = :preco WHERE id = :id";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':modelo', $modelo);
$stmt->bindParam(':cor', $cor);
$stmt->bindParam(':ano', $ano);
$stmt->bindParam(':preco', $preco);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
 
if ($stmt->execute())
{
    header('Location: index_carro.php');
}
else
{
    echo "Erro ao alterar";
    print_r($stmt->errorInfo());
}

?>