<?php
require './init.php';
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
 
        <title>Cadastro de Usuário - ULTIMATE PHP</title>
    </head>
 
    <body>
 
        <h1>Sistema de Cadastro - ULTIMATE PHP</h1>
 
        <h2>Cadastro de Usuário</h2>
         
        <form action="add_formulario.php" method="post">
            <label for="modelo">Modelo do Carro: </label>
            <br>
            <input type="text" name="modelo" id="modelo">
 
            <br><br>
 
            <label for="cor">Cor do Carro: </label>
            <br>
            <input type="text" name="cor" id="cor">
 
            <br><br>
             <label for="ano">Ano do Carro: </label>
            <br>
            <input type="date" name="ano" id="ano">
 
            <br><br> <label for="preco">Preço do Carro: </label>
            <br>
            <input type="number" name="preco" id="preco">
 
            <br><br>
             
           
            <input type="submit" value="Cadastrar">
        </form>
 
    </body>
</html>