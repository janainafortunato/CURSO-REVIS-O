<?php
require_once './init.php';
 
// abre a conexão
$PDO = db_connect();
 
// SQL para contar o total de registros
// A biblioteca PDO possui o método rowCount(), mas ele pode ser impreciso.
// É recomendável usar a função COUNT da SQL
// Veja o Exemplo 2 deste link: http://php.net/manual/pt_BR/pdostatement.rowcount.php
$sql_count = "SELECT COUNT(*) AS total FROM carro ORDER BY modelo ASC";
 
// SQL para selecionar os registros
$sql = "SELECT id, modelo, cor, ano, preco FROM carro ORDER BY modelo ASC";
 
// conta o toal de registros
$stmt_count = $PDO->prepare($sql_count);
$stmt_count->execute();
$total = $stmt_count->fetchColumn();
 
// seleciona os registros
$stmt = $PDO->prepare($sql);
$stmt->execute();
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
 
        <title>Sistema de Cadastro - ULTIMATE PHP</title>
    </head>
 
    <body>
         
        <h1>Sistema de Cadastro - ULTIMATE PHP</h1>
         
        <p><a href="formulario.php">Adicionar Carro</a></p>
 
        <h2>Lista de Usuários</h2>
 
        <p>Total de Carros: <?php echo $total ?></p>
 
        <?php if ($total > 0): ?>
 
        <table width="50%" border="1">
            <thead>
                <tr>
                    <th>Modelo</th>
                    <th>Cor</th>
                    <th>Ano</th>
                    <th>Preço</th>
                   
                </tr>
            </thead>
            <tbody>
                <?php while ($carro = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><?php echo $carro['modelo'] ?></td>
                    <td><?php echo $carro['cor'] ?></td>
                    <td><?php echo $carro['ano'] ?></td>
                    <td><?php echo $carro['preco'] ?></td>
                  
                    <td>
                        <a href="formulario_edite.php?id=<?php echo $carro['id'] ?>">Editar</a>
                        <a href="delete.php?id=<?php echo $carro['id'] ?>" onclick="return confirm('Tem certeza de que deseja remover?');">Remover</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
 
        <?php else: ?>
 
        <p>Nenhum carro registrado</p>
 
        <?php endif; ?>
    </body>
</html>