<?php
 
require_once './init.php';
 
// pega os dados do formuário
$modelo = isset($_POST['modelo']) ? $_POST['modelo'] : null;
$cor = isset($_POST['cor']) ? $_POST['cor'] : null;
$ano = isset($_POST['ano']) ? $_POST['ano'] : null;
$preco = isset($_POST['preco']) ? $_POST['preco'] : null;
 
 
// validação (bem simples, só pra evitar dados vazios)
if (empty($modelo) || empty($cor) || empty($ano) || empty($preco))
{
    echo "Volte e preencha todos os campos";
    exit;
}
 

// insere no banco
$PDO = db_connect();
$sql = "INSERT INTO carro(modelo, cor, ano, preco) VALUES(:modelo, :cor, :ano, :preco)";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':modelo', $modelo);
$stmt->bindParam(':cor', $cor);
$stmt->bindParam(':ano', $ano);
$stmt->bindParam(':preco', $preco);
 
 
if ($stmt->execute())
{
    header('Location: index.php');
}
else
{
    echo "Erro ao cadastrar";
    print_r($stmt->errorInfo());
}

?>