<!DOCTYPE html>
<html>
<head>
	<title>sistema de Cadastro de Carros</title>
</head>
<body>

	<a href="formualrio.php">Cadastra Um Carro</a>

	<br><br>

	<a href="form_pessoa.php">Volta para Cadastro de Pessoas</a>

	<br><br>

	

</body>
</html>