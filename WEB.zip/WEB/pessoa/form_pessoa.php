<?php
require './init.php';
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
 
        <title>Cadastro de Usuário - ULTIMATE PHP</title>
    </head>
 
    <body>
 
        <h1>Sistema de Cadastro - ULTIMATE PHP</h1>
 
        <h2>Cadastro de pesoa</h2>
         
        <form action="add_form_pessoa.php" method="post">
            <label for="name">Nome: </label>
            <br>
            <input type="text" name="name" id="name">
 
            <br><br>
 
            <label for="email">Email: </label>
            <br>
            <input type="text" name="email" id="email">
 
            <br><br>
               <label for="endereco">Endereço: </label>
            <br>
            <input type="text" name="endereco" id="endereco">
 
            <br><br>
               <label for="cidade">Cidade: </label>
            <br>
            <input type="text" name="cidade" id="cidade">
            <br><br>
 
            <br><br>   <label for="password">Senha: </label>
            <br>
            <input type="text" name="password" id="password">
             
            
            <br><br>
 
            <input type="submit" value="Cadastrar">
        </form>
 
    </body>
</html>